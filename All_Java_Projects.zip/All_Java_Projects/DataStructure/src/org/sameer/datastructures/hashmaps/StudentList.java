package org.sameer.datastructures.hashmaps;

public class StudentList {
	private Node h;
	
	//Dummy Node h
	public StudentList() {
		h= new Node();
		h.data=null;
		h.next=null;
	}
	
	public boolean insertStudent(Student std) {
		Node n= new Node();
		n.data=std;
		n.next=h.next;
		h.next=n;
		return true;
	}
	
	public boolean rollNoExists(String rollNo) {
		Node temp1=h.next;
		boolean temp=false;
		while(temp1!=null) {
			if(rollNo.equals(temp1.data.getRollNo())) {
				temp=true;
			}
			temp1=temp1.next;
		}	
		return temp;
	}
	
	public Student fetchStudentData(String rollNo) {
		Student temp=new Student();
		temp=null;
		Node temp1=h.next;
		while(temp1!=null) {
			if(rollNo.equals(temp1.data.getRollNo())) {
				temp=temp1.data;
				break;
			}
			temp1=temp1.next;
		}	
		return temp;
	}
	
	public void deleteStudent(String rollNo) {
		Node p=h;
		Node q=h.next;
		
		if(q!=null && !(rollNo.equals(q.data.getRollNo()))){
			p=q;
			q=q.next;
		}
		
		if(q!=null) {
			p.next=q.next;
		}
		
		else
		System.out.println("Node not found");
	}
	
	public void showAll() {
		Node p=h.next;
		while(p!=null) {
			System.out.println("Name of Student: "+p.data.getName()+"Roll No: "+p.data.getRollNo()+"CGPA: "+ p.data.getCgpa());
			p=p.next;
		}
	}
	
	
	class Node{
		private Student data; 
		Node next;
	}

}
