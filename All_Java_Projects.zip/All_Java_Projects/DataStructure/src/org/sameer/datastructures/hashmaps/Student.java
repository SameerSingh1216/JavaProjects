package org.sameer.datastructures.hashmaps;

public class Student {

	private String Name;
	private String rollNo;
	private double cgpa;
	
	public Student(String name, String rollNo, double cgpa) {
		//super();
		Name = name;
		this.rollNo = rollNo;
		this.cgpa = cgpa;
	}
	
	public Student() {
	}

	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getRollNo() {
		return rollNo;
	}
	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}
	public double getCgpa() {
		return cgpa;
	}
	public void setCgpa(double cgpa) {
		this.cgpa = cgpa;
	}
	
}
