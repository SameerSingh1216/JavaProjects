package org.sameer.datastructures.hashmaps;

public class MAIN {

	public static void main(String[] args) {
		HashTable hashTable= new HashTable();
		
		Student stList1=new Student("sameer","1",3.2);
		Student stList2=new Student("ameer","2",3.3);
		Student stList3=new Student("meer","3",3.4);
		Student stList4=new Student("eer","4",3.5);
		Student stList5=new Student("er","5",3.6);
		Student stList6=new Student("r","6",3.7);
		
//		System.out.println("Name of Student: "+stList1.getName()+"Roll No: "+stList1.getRollNo()+"CGPA: "+ stList1.getCgpa());
		int stListKey1= hashTable.toHashCode(stList1.getRollNo());
		int stListKey2= hashTable.toHashCode(stList2.getRollNo());
		int stListKey3= hashTable.toHashCode(stList3.getRollNo());
		int stListKey4= hashTable.toHashCode(stList4.getRollNo());
		int stListKey5= hashTable.toHashCode(stList5.getRollNo());
		int stListKey6= hashTable.toHashCode(stList6.getRollNo());
		
		hashTable.insert(stListKey1, stList1);
		hashTable.insert(stListKey2, stList2);
		hashTable.insert(stListKey3, stList3);
		hashTable.insert(stListKey4, stList4);
		hashTable.insert(stListKey5, stList5);
		hashTable.insert(stListKey6, stList6);
		
		hashTable.showAll();
		
		
		

	}

}
