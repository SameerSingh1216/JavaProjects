package org.sameer.datastructures.hashmaps;

public class HashTable {

	private StudentList[] arr;
	private int size;
	private int totalStudents;
	
	public HashTable() {
		size=1000;
		arr= new StudentList[size];
	}
	
	public int toHashCode(String rollNo) {
		int addAscii=0;
		int codeValue=0;
		for(int i=0;i<rollNo.length();i++) {
			addAscii= addAscii + (int)rollNo.charAt(i);
		}
	//	System.out.println(arr.length);
		codeValue= addAscii % this.arr.length;
		return codeValue;
	}
	
	public boolean insert(int key, Student data) {
		if(arr[key]==null) {
			arr[key]= new StudentList();
		}
		arr[key].insertStudent(data);
		totalStudents++;
		return true;
	}
	
	public int getTotal() {
		return totalStudents;
	}
	
	public Student fetchStudentInfo(String rollNo) {
		int key=toHashCode(rollNo);
		Student st= new Student();
		if(arr[key]==null) {
			return null;
		}	
		else {
			st=arr[key].fetchStudentData(rollNo);
		}
		return st;
	}
	
	public boolean deleteStudent(String rollNo) {
		int key = toHashCode(rollNo);
		if(arr[key]==null) {
			System.out.println("No Data");
			return false;
		}
		else {
			arr[key].deleteStudent(rollNo);
			totalStudents--;
			return true;
		}
	}
	
	public void showAll() {
		for(int i=0; i<arr.length;i++) {
			if(arr[i]!=null) {
				arr[i].showAll();
			}
		}
	}
}
