package org.sameer.datastructures;

//import org.sameer.datastructures.BST.Node;

public class Node {

	Node lc;
	Person data;
	Node rc;
	public Node getLc() {
		return lc;
	}
	public void setLc(Node lc) {
		this.lc = lc;
	}
	public Person getData() {
		return data;
	}
	public void setData(Person data) {
		this.data = data;
	}
	public Node getRc() {
		return rc;
	}
	public void setRc(Node rc) {
		this.rc = rc;
	}
	
	
}
