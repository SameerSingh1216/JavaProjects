package org.sameer.datastructures;

public class CallPerson {

	public static void main(String[] args) {
			Person p1= new Person("Sameer", 23);
			Person p2= new Person("ameer", 24);
			Person p3= new Person("Zmeer", 25);
			Person p4= new Person("eer", 26);
			Person p5= new Person("er", 27);
			
			BST bst= new BST();
			bst.insert(p1);
			bst.insert(p2);
			bst.insert(p3);
			bst.insert(p4);
			bst.insert(p5);
			
			
			//bst.showAll(bst.findNode("Sameer"));
			Node n1= new Node();
			n1= bst.findNode("Sameer");
			System.out.println("Name:"+ n1.getData().getName()+ "Age:" + n1.getData().getAge());
			

	}

}
