package org.sameer.datastructures;

public class Person {

	String Name;
	int Age;
	public Person(String name, int Age) {
		setName(name);
		setAge(Age);
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	
	public String getAllDetails() {
		return "The person Name :" +this.getName() + "Age:" + this.getAge();
	}
}
