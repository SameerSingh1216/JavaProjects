package org.sameer.javabrains.model;

import javax.persistence.Entity;
import javax.persistence.Id;

//import org.hibernate.annotations.Entity;

@Entity
public class Circle {

	@Id
	private int ID;
	private String Name;
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		this.ID = iD;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		this.Name = name;
	}
	public Circle(int iD, String name) {
		//super();
		this.ID = iD;
		this.Name = name;
	}
	public Circle() {
		
	}
	
	
}
