package org.sameer.javabrains;

import java.util.ArrayList;
import java.util.List;

import org.sameer.javabrains.dao.HibernateDaoImpl;
import org.sameer.javabrains.dao.JdbcDemoImpl;
import org.sameer.javabrains.dao.SimpleJdbcDaoImpl;
import org.sameer.javabrains.model.Circle;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class JdbcDemo {

	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
		HibernateDaoImpl dao= (HibernateDaoImpl)ctx.getBean("hibernateDaoImpl");
	   // List<Circle> cr= new ArrayList<Circle>();
		// Circle circle = dao.getCircle(1);
		//System.out.println(circle.getName());
	    //int numberOfCircle= dao.getCircleCount();
	   // System.out.println(numberOfCircle);
	    //System.out.println(dao.getCircleName(1));
	    //System.out.println(dao.getCircleForId(2).getName());
//	    Circle circle= new Circle(7,"7th Circle");
//	    dao.insertCircle(circle);
//	    cr= dao.getAllCircle();
//	    for (Circle i: cr)
//	    {
//	    	System.out.println("Circle Id: " +i.getID() +" Circle Name: "+ i.getName());
//	    }
	    
	    
	    System.out.println(dao.getCircleCount());
	    
	    //dao.createTriangleTable();

	}

}
