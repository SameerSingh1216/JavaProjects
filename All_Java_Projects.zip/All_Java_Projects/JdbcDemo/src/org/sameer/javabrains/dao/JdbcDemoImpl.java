package org.sameer.javabrains.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.sameer.javabrains.model.Circle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

@Component
public class JdbcDemoImpl {
	
	private DataSource dataSource;
	JdbcTemplate jdbcTemplate;
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public DataSource getDataSource() {
		return dataSource;
	}
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
		this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public Circle getCircle(int circleId)
	{	
		Connection conn= null;
		try {
		
		conn= dataSource.getConnection();
		PreparedStatement ps= conn.prepareStatement("Select * from Circle where id=?");
		ps.setInt(1, circleId);
		
		Circle circle=null;
		ResultSet Rs= ps.executeQuery();
		while(Rs.next())
		{
		circle= new Circle(circleId, Rs.getString("name"));
		}
		Rs.close();
		ps.close();
		return circle;
		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
		}
		finally
		{
			try {
				conn.close();
			}
			catch(SQLException e) {}
		}
		
	}
	
	public int getCircleCount() {	
		String sql = "Select count(*) from circle";
		return jdbcTemplate.queryForInt(sql);
	}
	
	public String getCircleName(int circleId) {	
		String sql = "Select name from circle where id=?";
		return jdbcTemplate.queryForObject(sql, new Object[] {circleId}, String.class);
	}
	
	public Circle getCircleForId(int circleId) {	
		String sql = "Select * from circle where id=?";
		return jdbcTemplate.queryForObject(sql, new Object[] {circleId}, new CircleMapper());
	}
	
	public List<Circle> getAllCircle() {	
		String sql = "Select * from circle";
		return jdbcTemplate.query(sql,new CircleMapper());
	}
	
//	public void insertCircle(Circle circle) {
//		String sql ="insert into circle(ID,NAME) values(?,?)";
//		jdbcTemplate.update(sql, new Object[] {circle.getID(),circle.getName()});
//	}
	
	public void insertCircle(Circle circle) {
		String sql ="insert into circle(ID,NAME) values(:ID,:NAME)";
		SqlParameterSource namedParameter = new MapSqlParameterSource("ID",circle.getID()).addValue("NAME", circle.getName());
		namedParameterJdbcTemplate.update(sql, namedParameter);
	}

	public void createTriangleTable() {
		String sql="create table Traingle1 (ID Integer, Name varchar(50))";
		jdbcTemplate.execute(sql);
	}
	private static final class CircleMapper implements RowMapper<Circle>{

		@Override
		public Circle mapRow(ResultSet resultSet, int arrowNum) throws SQLException {
			Circle circle= new Circle();
			circle.setName(resultSet.getString("name"));
			circle.setID(resultSet.getInt("ID"));		
			return circle;
		}
		
	}
}
