package io.javabrains;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.*;
import static org.junit.jupiter.api.Assertions.assertAll;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestReporter;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@DisplayName("While Running MathUtilTest..")
class MathUtilsTest {
	
	MathUtils mu;
	TestInfo tstinfo;
	TestReporter tstReport;
	
	@BeforeAll
	void beforeAllInit()
	{
		System.out.println("This needs to be run before all inti..");
	}
	
	@AfterEach
	void cleanUp()
	{
		System.out.println("Cleaning...");
	}
	
	@BeforeEach
	void init(TestInfo tstinfo, TestReporter tstReport) 
	{
		this.tstinfo= tstinfo;
		this.tstReport = tstReport;
		mu = new MathUtils();
		tstReport.publishEntry("Currently test Running " + tstinfo.getDisplayName() + "with Tag " + tstinfo.getTags());
	}
	
	
	@Nested
	@DisplayName("Add method check")
	@Tag("Math")
	class Add
	{
	@Test
	@DisplayName("Add +ve Num check")
	void addPositiveNum() {
		//assertEquals(2,mu.add(1, 1), "The add method problem");
		int expected = 2;
		int actual = mu.add(1, 1);
		assertEquals(expected ,actual, () -> "Expected:" + expected + "but o/p: "+ actual);
	}
	
	@Test
	@DisplayName("Add -ve Num check")
	void addNegativeNum() {
		//MathUtils mu = new MathUtils();
		assertEquals(-2,mu.add(-2, 0), "The add method problem");
	}
	
	}
	@Test
	@DisplayName("Divide method check")
	@Tag("Math")
	void testDivide() {
		//MathUtils mu = new MathUtils();
		//int actual = mu.add(1, 1);
		assertThrows(ArithmeticException.class, ()->mu.divide(1, 0) , "The Divide method problem");
		//assertThrows(NullPointerException.class, ()->mu.divide(1, 0) , "The Divide method problem");
	}
	
	@Test
	@DisplayName("multiply method check")
	@Tag("Math")
	void testMultiply() {
	
		assertAll(
				() -> assertEquals(4, mu.multiply(2, 2)),
				() -> assertEquals(-2, mu.multiply(-1, 2)),
				() -> assertEquals(0, mu.multiply(-1, 0))
				);
				
				
	}
	
	@RepeatedTest(3)
	@DisplayName("Compute Area method check")
	@Tag("Circle")
	void testcomputeCircleArea(RepetitionInfo repeatNum) {
		
		if (repeatNum.getCurrentRepetition()==1)
		{
		boolean Check= true;
		assumeTrue(Check);
		//@assumeTrue(check);
		//MathUtils mu = new MathUtils();
		double actual = mu.computeCircleArea(1);
		assertEquals(3.141592653589793,actual, "computeCircleArea method" + repeatNum.getCurrentRepetition());
		}
		if (repeatNum.getCurrentRepetition()==2)
		{
		boolean Check= false;
		assumeTrue(Check);
		//@assumeTrue(check);
		//MathUtils mu = new MathUtils();
		double actual = mu.computeCircleArea(1);
		assertEquals(3.141592653589793,actual, "computeCircleArea method" + repeatNum.getCurrentRepetition());
		}
		if (repeatNum.getCurrentRepetition()==3)
		{
		boolean Check= false;
		assumeTrue(Check);
		//@assumeTrue(check);
		//MathUtils mu = new MathUtils();
		double actual = mu.computeCircleArea(1);
		assertEquals(3.141592653589793,actual, "computeCircleArea method" + repeatNum.getCurrentRepetition());
		}
	}

	@Test
	@Disabled
	void justCheck() {
	fail("All failed");
	}
}
