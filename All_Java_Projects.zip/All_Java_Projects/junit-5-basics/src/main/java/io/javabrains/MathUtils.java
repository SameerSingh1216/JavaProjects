package io.javabrains;

public class MathUtils {
	
	int add(int a, int b)
	{
		return a+b;
	}
	
	int sub(int a, int b)
	{
		return a-b;
	}
	
	int multiply(int a, int b)
	{
		return a*b;
	}
	
	int divide(int a, int b)
	{
		return a/b;
	}

	double computeCircleArea(double d)
	{
		return Math.PI*d*d;
	}
}
