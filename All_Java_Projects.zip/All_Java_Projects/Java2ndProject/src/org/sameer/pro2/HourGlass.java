package org.sameer.pro2;

import java.util.Scanner;

public class HourGlass {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int a[][] = new int[6][6];
		int sumMax=Integer.MIN_VALUE;
		int sum=Integer.MIN_VALUE;
		for (int i=0; i<6;i++) {
			for(int j=0; j<6; j++) {
				a[i][j]= scan.nextInt();
				if(i>1 && j>1) {
					sum= a[i][j]+a[i][j-1]+a[i][j-2]+a[i-1][j-1]+a[i-2][j]+a[i-2][j-1]+a[i-2][j-2];
				}
				if(sum>sumMax) {
					sumMax=sum;
				}
			}
		}
		
		System.out.println(sumMax);

	}
}
