package org.sameer.pro2;

import java.util.ArrayList;
import java.util.Scanner;

public class SubStringLstSmt {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
        String S= sc.next();
        int len= S.length();
        ArrayList<String> S1= new ArrayList<String>();
        for(int i=0; i<len; i+=3){
            S1.add(S.substring(i,i+3));
        }
        String Lstr= S1.get(0);
        String Sstr= S1.get(0);
        for(int j=1;j<S1.size(); j++){
            if (S1.get(j).compareTo(Lstr) >0)
                Lstr=S1.get(j);
            if (S1.get(j).compareTo(Sstr) <0)
                Sstr=S1.get(j); 
        }
        System.out.println(Sstr);
        System.out.println(Lstr);

	}

}

/******************Alternative Code with another Logic**************/
//import java.util.Scanner;
//
//public class Solution {
//
//    public static String getSmallestAndLargest(String S, int k) {
//        String smallest = "";
//        String largest = "";
//        
//       // Scanner sc= new Scanner(System.in);
//        //String S= sc.next();
//        int len= S.length();
//        String smalles="";
//        String subStr="";
//        //ArrayList<String> S1= new ArrayList<String>();
//        for(int i=0; i<=len-k; i++){
//            subStr=S.substring(i,i+k);
//            if(i==0){
//                smallest= subStr;
//            }
//            if(subStr.compareTo(largest)>0)
//                largest=subStr;
//            else if(subStr.compareTo(smallest)<0)
//                smallest=subStr;
//        }
//        // String LStr= S1[0];
//        // String SStr= S1[0];
//        // for(int j=1;j<S1.size(); j++){
//        //     if (S1[j].compareTo(LStr) >0)
//        //         Lstr=S1[j];
//        //     if (S1[j].compareTo(SStr) <0)
//        //         Sstr=S1[j]; 
//        // }
//        //System.out.println(Lstr);
//        //System.out.println(Sstr);
//        
//        // Complete the function
//        // 'smallest' must be the lexicographically smallest substring of length 'k'
//        // 'largest' must be the lexicographically largest substring of length 'k'
//        
//        return smallest + "\n" + largest;
//    }
//
//
//    public static void main(String[] args) {
//        Scanner scan = new Scanner(System.in);
//        String s = scan.next();
//        int k = scan.nextInt();
//        scan.close();
//      
//        System.out.println(getSmallestAndLargest(s, k));
//    }
//}
/********************************************************************/
