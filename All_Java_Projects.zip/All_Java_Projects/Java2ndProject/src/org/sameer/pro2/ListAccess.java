package org.sameer.pro2;
import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class ListAccess {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
       List<Integer> lst= new ArrayList<Integer>();
       int n= sc.nextInt();
       for (int i=0; i<n; i++){
            lst.add(sc.nextInt());
       }
//        String s;
//        int index=0;
//        int num=0;
//        int delIndex=0;
        int numOfQuery= sc.nextInt();
     //  sc.nextLine();
       for(int j=0; j<numOfQuery; j++){
           String s= sc.next();
           if(s.equals("Insert")){
                int index= sc.nextInt();
                int num= sc.nextInt();
                lst.add(index, num);
           }
           else{
               int delIndex=sc.nextInt();
                lst.remove(delIndex);
           }
       }
       sc.close();
       for (int x: lst) {
       System.out.print(x+" ");
       }
    }
}

