package org.sameer.pro2;
import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class NegativeSum {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n= scan.nextInt();
        scan.nextLine();
        String data = scan.nextLine();

        String tmpDataArray[] = data.split(" ");
        int count=0;
        

        int dataArray[] = new int[tmpDataArray.length];
        for (int i = 0; i < dataArray.length; ++i) {
          dataArray[i] = Integer.parseInt(tmpDataArray[i]);
        }

        for(int j=0; j<dataArray.length;j++){
            int sum=0;
            for(int k=j; k<dataArray.length;k++){
                sum =sum+dataArray[k];
                if(sum<0)
                count++;
            }
        }
        System.out.println(count);
    }
}   
