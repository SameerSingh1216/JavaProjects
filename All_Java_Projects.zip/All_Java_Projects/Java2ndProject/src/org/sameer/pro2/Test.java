package org.sameer.pro2;

public class Test implements Runnable{

	public static void main(String[] args) throws InterruptedException{
		
		Thread t1= new Thread(new Test());
		t1.start();
t1.sleep(500);
		System.out.println("Begin");
		t1.join();
		System.out.println("End");
	}
	
	public void run() {
		System.out.println("run");
	}

}
