package org.sameer.pro2;

import java.util.Scanner;

public class IpAddressValidation {

	public static void main(String[] args) {
		boolean flag=false;
		Scanner sc= new Scanner(System.in);
		int No= sc.nextInt();
		for(int i=0;i<No;i++) {
		String str= sc.next();
		String[] arr= str.trim().split("[.]+");
		//System.out.println(arr.length);
		long count = str.chars().filter(ch -> ch == '.').count();
		if(arr.length>4 || count>3) {
			System.out.println("false");
			
		}
		for (int j=0; j<arr.length; j++) {
			try{
				int x= Integer.parseInt(arr[j]);
				if(x>255) {
					flag=false;
					break;}
				else {
					flag = true;
				}
			}
			catch(Exception e) {
				System.out.println("false");
			}
			
		}
		
		if(flag==false) {
			System.out.println("flase");
		}
		
		else {
			System.out.println("true");
		}
	}
}

}
