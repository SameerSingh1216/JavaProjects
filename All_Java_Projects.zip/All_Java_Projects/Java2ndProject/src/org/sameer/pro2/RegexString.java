package org.sameer.pro2;

import java.util.Scanner;

public class RegexString {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String s = scan.nextLine();
        String[] arrOfStr = s.split("[ !,?.\\_'@]+"); 
  
        System.out.println(arrOfStr.length);
        for (String a : arrOfStr){ 
            System.out.println(a);
    } 
        scan.close();
    }
}
