package org.sameer.pro2;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class JavaStream {

	public static void main(String args[]) throws IOException{
	
		String []arr= {"Same","Sad","ser","adfef"};
		Arrays.stream(arr).filter(x->x.startsWith("S")).sorted().forEach(System.out::print);
		//System.out.println(IntStream.range(1,2).sum());
		
		//Stream.of("Aviva","Akit","ankit").sorted().findFirst().ifPresent(System.out::print);
		System.out.println();
		
		int a[]= {1,2,3,4,2,3};
		Arrays.stream(a).map(x->x*x).average().ifPresent(System.out::print);
		System.out.println(" ");
		
		List<String> str= Arrays.asList("addasd","dasdad","adasdd","daswr");
		str.stream().map(String::toLowerCase).filter(x->x.startsWith("a")).forEach(System.out::print);
		
		System.out.println(" ");
		
		//To create a stream
		
		
		
//		List<String> band= Files.lines(Paths.get("src/band.txt")).filter(x->x.contains("H")).
//				collect(Collectors.toList());
//		
//		System.out.println(band);
		Stream<String> filee= Files.lines(Paths.get("src/band.txt"));
		filee.map(x->x.split(",")).filter(x->x.length<3).forEach(x->{if(x.length>1) System.out.print(x[0]+x[1]);});
//		System.out.println("Wrong rows="+ count);
//		count.forEach(x->System.out.println(count));
		//band.close();
		System.out.println();
		
		double total = Stream.of(7.0,7.9,9.0).reduce(0.0, (Double aa, Double b)->aa+b);
		System.out.println(total);
		
		IntSummaryStatistics summary= IntStream.of(3,4,5,6,7).summaryStatistics();
		
		System.out.println(summary);
		
		List<Integer> lst1 = Arrays.asList(1,2,3,4,5);
		Stream<Integer> Str1= lst1.stream();
		Str1.forEach(System.out::print);
		}
}
