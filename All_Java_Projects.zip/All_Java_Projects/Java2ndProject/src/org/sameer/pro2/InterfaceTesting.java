package org.sameer.pro2;

public interface InterfaceTesting {
	public void show();
}
