package org.sameer.pro2;

public class TestingClass implements InterfaceTesting {

	public static void main(String[] args) {
		
		InterfaceTesting I;
		I = new TestingClass();
		//I.show();
		//I.Display(); //Cannot be done since interfaces obj
		
		TestingClass TC= new TestingClass();
		TC.show();
		TC.Display();

	}

	@Override
	public void show() {
		System.out.println("Hi baby!!!");
		
	}
	
	public void Display() {
		System.out.println("Hi baby Display!!!");
		
	}

}
