
import java.util.Arrays;
public class BinarySearch {

	public static void main(String[] args) {
		int a[]= {1,5,3,4,2};
		int l=a.length;
		//Arrays.sort(a);
		int x=2;
		//int index= binarySearch(a,l-1,x);
		//System.out.printf("element %d id present at %d", x,index);
		
		int linerresult= linearSearch(a,l,x);
		System.out.printf("element %d id present at %d", x,linerresult);
	}
public static int binarySearch(int a[],int l,int x) {
	
	//int middle=(int)l/2;
	int z=0;
	
	while(z<=l) {
		
		int middle= z+(l-z)/2;
		
		if(a[middle]== x) {
			return middle;
		}
		
		if(a[middle]< x) {
			z=middle+1;
		}
		
		else {
			l=middle-1;
		}
	}
	
	return -1;
}

public static int linearSearch(int a[], int l, int x)
{
	for(int i=0; i<l;i++) {
		if(a[i]==x)
			return i;
	}
	return -1;
}
}
