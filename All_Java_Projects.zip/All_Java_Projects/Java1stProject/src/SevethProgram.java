import java.util.Scanner;
import java.lang.Math;

public class SevethProgram {

	public static void main(String []argh){
        Scanner in = new Scanner(System.in);
        int t=in.nextInt();
        int x=0;
        for(int i=0;i<t;i++)
        {
            int a = in.nextInt();
            int b = in.nextInt();
            int n = in.nextInt();
            x=a;
            for(int y=0; y<n; y++)
            {
                x += Math.pow(2,y)*b;
                System.out.print(x+ " ");
            }
            x=0;
            System.out.println();
            
        }
        
        in.close();
    }

}
