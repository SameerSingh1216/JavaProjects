import java.util.Arrays;

public class PassByRef {

	public static void main(String[] args) {
		int[] a=  {1,2,3};
		
		System.out.println("Bfr pass by ref:");	
		for (int i=0;i<3;i++) {
			System.out.println(a[i]);
		}	
		int [] b= checkPassbyRef(a);
		System.out.println("After pass by ref:");	
		for (int i=0;i<3;i++) {
			System.out.println(b[i]);
		}
		
		System.out.println("Bfr pass by ref:");	
		for (int i=0;i<3;i++) {
			System.out.println(a[i]);
		}
		
		int z= search(a,3);
		System.out.println("index :"+z);
		Arrays.sort(a);
		System.out.println("After sorting..");
		for (int i=0;i<3;i++) {
			System.out.println(a[i]);
		}
	}
	
	public static int [] checkPassbyRef(int a[]) {
		int temp =a[0];	
		a[0]= a[1];
		a[1]= temp;
		return a;
	}
	
	public static int search(int arr[], int x) {
		for(int i=0; i<arr.length;i++) {
			if(arr[i]==x) {
				return i;
			}
		}
		
		return -1;
	}

}
