import java.util.*;

//import javax.sound.midi.SysexMessage;

public class SecoundProgramJava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		int a = in.nextInt();
		int b = in.nextInt();
		int c = in.nextInt();
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		//System.out.println("Hi");
		in.close();

	}

}
