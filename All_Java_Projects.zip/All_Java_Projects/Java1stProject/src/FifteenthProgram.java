//import java.io.*;
//import java.lang.*;
public class FifteenthProgram {
	public static void main(String [] args) {
	System.out.println( "Each team has n players in ");
	}

}
