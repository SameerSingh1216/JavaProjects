
interface A {
	
	public void ShowA();

}

interface B {
	
	public void ShowB();

}

class D implements A,B {
	
	public void ShowA( ) {
		System.out.println("Hi Man A");
	}
	public void ShowB( ) {
		System.out.println("Hi Man B");
	}	
	
	public static void main(String[] args)
	{
		A obj1 = new D();
		B obj2 = new D();
		
		obj1.ShowA();
		obj2.ShowB();
	}

}

