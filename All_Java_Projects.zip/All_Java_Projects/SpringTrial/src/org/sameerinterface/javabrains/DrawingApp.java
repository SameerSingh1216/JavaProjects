package org.sameerinterface.javabrains;

import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DrawingApp {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring2.xml");
		Shape sh = (Shape) context.getBean("circle");
		sh.Draw();
		//System.out.println(context.getMessage("Greetings", null, "Default Greetings", null));

	}

}
