package org.sameerinterface.javabrains;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.stereotype.Component;

@Component
public class Circle implements Shape, ApplicationEventPublisherAware{

	private Point centre;
	private ApplicationEventPublisher publisher;
	
	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher publisher) {
		this.publisher = publisher;
		
	}

	public Point getCentre() {
		return centre;
	}

	@Required
	@Autowired
	@Qualifier("ForCircle")
	// Using JRS250 Package for Bean initialization
	//@Resource(name="Point2")
	public void setCentre(Point centre) {
		this.centre = centre;
	}
	
	@Override
	public void Draw() {
		System.out.println("In Circle Draw Method..");
		System.out.println("The centre of the circle (X,Y) : (" + centre.getX()+ ","+centre.getY()+ ")");
		DrawEvent drawEvent= new DrawEvent(this);
		publisher.publishEvent(drawEvent);	
	}
	
}
