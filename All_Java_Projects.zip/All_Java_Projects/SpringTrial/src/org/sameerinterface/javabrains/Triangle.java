package org.sameerinterface.javabrains;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;

//import org.springframework.context;

public class Triangle implements Shape{
	private Point PointA;
	private Point PointB;
	private Point PointC;
	
	private MessageSource MessageSource;
	
	public MessageSource getMessageSource() {
		return MessageSource;
	}
	
	@Autowired
	public void setMessageSource(MessageSource messageSource) {
		MessageSource = messageSource;
	}
	
	public Point getPointA() {
		return PointA;
	}
	public void setPointA(Point pointA) {
		PointA = pointA;
	}
	public Point getPointB() {
		return PointB;
	}
	public void setPointB(Point pointB) {
		PointB = pointB;
	}
	public Point getPointC() {
		return PointC;
	}
	public void setPointC(Point pointC) {
		PointC = pointC;
	}
	
	@Override
	public void Draw() {
		System.out.println(MessageSource.getMessage("shape.Triangle", null, "Default shape Triangle", null));
		System.out.println(MessageSource.getMessage("co-ordinates", new Object[] {PointA.getX(),PointA.getY()},"Default coordinates (0,0)",null));
		System.out.println(MessageSource.getMessage("co-ordinates", new Object[] {PointB.getX(),PointB.getY()},"Default coordinates (0,0)", null));
		System.out.println(MessageSource.getMessage("co-ordinates", new Object[] {PointC.getX(),PointC.getY()},"Default coordinates (0,0)", null));
		System.out.println(MessageSource.getMessage("Greetings", null, "Default Greetings", null));	
	}
	
	

}
