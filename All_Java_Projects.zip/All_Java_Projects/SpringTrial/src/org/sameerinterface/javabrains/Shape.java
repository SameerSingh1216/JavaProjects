package org.sameerinterface.javabrains;

public interface Shape {

	public void Draw();
}
