package org.sameer.javabrains;

import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class Triangle implements ApplicationContextAware, BeanNameAware{
	
	private List<Point> lst;
	private ApplicationContext context= null;	

	
	public List<Point> getLst() {
		return lst;
	}


	public void setLst(List<Point> lst) {
		this.lst = lst;
	}


	void Draw() {
		
		for(Point i : lst)
		{
			System.out.println("Co-ordinates of Point are: (" + i.getX() + ","+ i.getY() +")");
		}
//		System.out.println("Co-ordinates of Point A are: (" + getPointA().getX() + ","+ getPointA().getY() +")");
//		System.out.println("Co-ordinates of Point B are: (" + getPointB().getX() + ","+ getPointB().getY() +")");
//		System.out.println("Co-ordinates of Point C are: (" + getPointC().getX() + ","+ getPointC().getY() +")");
	}


	@Override
	public void setApplicationContext(ApplicationContext context) throws BeansException {
		this.context = context;
		
	} //Just if you want to initialise beans from this class you can use contex now and getBean


	@Override
	public void setBeanName(String BeanName) {
		System.out.println("Bean NAme: "+ BeanName);
		
	}

	//For getting the bean name
	
	
	
	
	
	/*private Point PointA;
	private Point PointB;
	private Point PointC;
	
	
	public Point getPointA() {
		return PointA;
	}


	public void setPointA(Point pointA) {
		PointA = pointA;
	}


	public Point getPointB() {
		return PointB;
	}


	public void setPointB(Point pointB) {
		PointB = pointB;
	}


	public Point getPointC() {
		return PointC;
	}


	public void setPointC(Point pointC) {
		PointC = pointC;
	}*/

	/*private String type;
	private int height;
	
	public Triangle(String type) {
		//super();
		this.type = type;
	}
	
	public Triangle(String type, int height) {
		//super();
		this.type = type;
		this.height = height;
	}
	
	public String getType() {
		return type;
	}
	
	public int getHeight() {
		return height;
	}
	public void setType(String type) {
		this.type = type;
	}*/
	//void Draw() {
		//System.out.println("Triangle.." + "The type of triangle is: "+ getType() +"The height is :" + getHeight());
	//}

}
