package org.sameer.javabrains;

import java.util.List;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Triangle1 implements InitializingBean, DisposableBean{

	private List<Point> lst;
	
	public List<Point> getLst() {
		return lst;
	}

	public void setLst(List<Point> lst) {
		this.lst = lst;
	}

	
	public void Draw() {
		
		for(Point i: lst)
		{
		System.out.println("Points are: (" + i.getX() + ","+ i.getY() +")");
		}
	}
//	private Point PointB;
//	private Point PointC;

	
	@Override
	public void afterPropertiesSet() throws Exception {

		System.out.println("Init Bean done..");
		
	}
	
	@Override
	public void destroy() throws Exception {
		System.out.println("Destroy Bean done..");
		
	}
	
	public void myInit()
	{
		System.out.println("myInit...");
	}
	
	public void myDestroy()
	{
		System.out.println("myDestroy...");
	}

	
	
	/*public Point getPointA() {
		return PointA;
	}
	public void setPointA(Point pointA) {
		PointA = pointA;
	}
	public Point getPointB() {
		return PointB;
	}
	public void setPointB(Point pointB) {
		PointB = pointB;
	}
	public Point getPointC() {
		return PointC;
	}
	public void setPointC(Point pointC) {
		PointC = pointC;
	}*/
	
	
	/*void Draw() {
		System.out.println("Co-ordinates of Point A are: (" + getPointA().getX() + ","+ getPointA().getY() +")");
		System.out.println("Co-ordinates of Point B are: (" + getPointB().getX() + ","+ getPointB().getY() +")");
		System.out.println("Co-ordinates of Point C are: (" + getPointC().getX() + ","+ getPointC().getY() +")");
	}*/
	
	
}
