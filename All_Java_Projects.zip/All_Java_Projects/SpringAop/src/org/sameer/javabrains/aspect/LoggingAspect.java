package org.sameer.javabrains.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.sameer.javabrains.model.Circle;

//@Aspect
public class LoggingAspect {

//	@Before("allGetters() && allCircleMethods()")
//	public void loggingAspect(JoinPoint joinPoint) {
//		//System.out.println("Logging Advice Run..");
//		Circle cr = (Circle)joinPoint.getTarget();
//		System.out.println(joinPoint);
//		cr.setName("new Circle");
//		System.out.println(cr.getName());
//	}
	
//	@Before("args(name)")
//	public void loggingAdvice(String name) {
//		System.out.println(name);
//	}
	
//	@AfterReturning(pointcut="args(name)", returning="returnName")
//	public void afterReturning(String name, Object returnName) {
//		System.out.println("afterReturning Run.. name :"+name +" after returning the value: "+ returnName);
//	}
//	
//	@AfterThrowing(pointcut="args(name)", throwing="ex")
//	public void afterThrowing(String name, Exception ex) {
//		System.out.println("afterThrowing. name :"+name+ "  Exception is:" + ex);
//	}
//	
	//@Around("@annotation(org.sameer.javabrains.aspect.Loggable)")
	public Object aroundMethod(ProceedingJoinPoint proceedingJoinPoint) {
		Object returnValue=null;
		try {
			System.out.println("Bfr proceedings...");
			returnValue= proceedingJoinPoint.proceed();
			System.out.println("Aftr proceedings...");
		} catch (Throwable e) {
			System.out.println("Exception :"+ e);
		}
		
		System.out.println("Finally :");
		return returnValue;
	}
	
//	@Pointcut("execution(* get*(..))")
//	public void allGetters() {
//		
//	}
//	
//	@Pointcut("within(org.sameer.javabrains.model.Circle)")
//	public void allCircleMethods() {
//		
//	}
//	
}
