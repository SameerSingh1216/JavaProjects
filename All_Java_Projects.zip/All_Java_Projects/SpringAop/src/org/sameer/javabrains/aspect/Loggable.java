package org.sameer.javabrains.aspect;

public @interface Loggable {

}
