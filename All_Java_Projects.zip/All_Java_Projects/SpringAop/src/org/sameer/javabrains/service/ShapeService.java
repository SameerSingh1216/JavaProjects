package org.sameer.javabrains.service;

import org.sameer.javabrains.aspect.Loggable;
import org.sameer.javabrains.model.Circle;
import org.sameer.javabrains.model.Triangle;

public class ShapeService {

	private Triangle triangle;
	private Circle circle;
	
	public Triangle getTriangle() {
		return triangle;
	}
	public void setTriangle(Triangle triangle) {
		this.triangle = triangle;
	}
	
	@Loggable
	public Circle getCircle() {
		System.out.println("In Circle..");
		return circle;
	}
	public void setCircle(Circle circle) {
		this.circle = circle;
	}
	
}
