package org.sameer.javabrains.model;

public class Circle {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void setNameReturnforException(String name) {
		this.name = name;
		throw(new RuntimeException());
	}
	
	public String setNameReturn(String name) {
		this.name = name;
		return name;
	}
	
}
